﻿namespace ServiceManagementApp.Data.Enums
{
    public enum ServiceRequestPriority
    {
        Low,
        Medium,
        High
    }
}
