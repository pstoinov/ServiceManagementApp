﻿namespace ServiceManagementApp.Data.Enums
{
    public enum Manufacturer
    {
        Tremol,
        Daisy
    }
}
