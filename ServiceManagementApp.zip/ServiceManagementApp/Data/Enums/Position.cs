﻿namespace ServiceManagementApp.Data.Enums
{
    public enum Position
    {
        Developer,
        Manager,
        Technician,
        Support
    }
}
